@extends('layouts.app')

@section('content')
   <br />
      <br />
      <br />
      <p><strong>Recent Featured Politician</strong></p>
 
      <br />
      <div class="row">
        <div class="col-md-4 text-center">
          <p style="text-align: justify;">
            Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on the 12th
            May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and.... Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on
            the 12th May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and.... Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on
            the 12th May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and....Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on the
            12th May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and....
          </p>
        </div>
        <div class="col-md-4 text-center">
          <img
            src="https://res.cloudinary.com/zennylily/image/upload/v1571784976/wikipoli_cn3w6g.jpg"
            class="img-fluid"
            alt=""
            width="100%"
            height="100"
          />
        </div>
        <div class="col-md-4 text-center">
          <p style="text-align: justify;">
            Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on the 12th
            May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and.. Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on the
            12th May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and.. Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on the
            12th May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and.. Adetokunbo Olufela Durotoye (born in Ibadan, Oyo State on the
            12th May 1971) is a business consultant, leadership expert and
            motivational speaker. Fela is the president of the GEMSTONE Nation
            Builders Foundation, non- profit, non- governmental organization
            targeted at training youths towards transformational leadership
            and..
          </p>
        </div>
      </div>
      <br />
      <br />
      <p style="text-align: justify;">
        He was the Nigerian Presidential Candidate of the Alliance for New
        Nigeria party (ANN) for the 2019 Presidential elections.
      </p>
      <p style="text-align: justify;">
        He was born to Lyiwola and Adeline Durotoye, both profesors at the
        University of Ife. After his parents moved to Obafemi Awolowo
        University, Ile- Ife, Fela attended the Staff Children’s School .
      </p>
      <p style="text-align: justify;">
        He was the Nigerian Presidential Candidate of the Alliance for New
        Nigeria party (ANN) for the 2019 Presidential elections. He was born to
        Lyiwola and Adeline Durotoye, both profesors at the University of Ife.
        After his parents moved to Obafemi Awolowo University, Ile- Ife, Fela
        attended the Staff Children’s School ...
      </p>
      <br />
      <a href="" id="more">Read More</a>
      <br />
      <br />
      <br />

      <p><strong>Political Update</strong></p>
      <ul>
        <li>
          <p style="text-align: justify;">
            Sowpre Omoyel, he was the Nigerian Presidential Candidate of the
            Alliance for New Nigeria party (ANN) for the 2019 Presidential
            elections. He was born to Lyiwola and Adeline Durotoye, both
            profesors at the University of Ife. After his parents moved to
            Obafemi Awolowo University, Ile- Ife, Fela attended the Staff
            Children’s School.
          </p>
        </li>
        <li>
          <p style="text-align: justify;">
            Sowpre Omoyel, he was the Nigerian Presidential Candidate of the
            Alliance for New Nigeria party (ANN) for the 2019 Presidential
            elections. He was born to Lyiwola and Adeline Durotoye, both
            profesors at the University of Ife. After his parents moved to
            Obafemi Awolowo University, Ile- Ife, Fela attended the Staff
            Children’s School.
          </p>
        </li>
        <li>
          <p style="text-align: justify;">
            Sowpre Omoyel, he was the Nigerian Presidential Candidate of the
            Alliance for New Nigeria party (ANN) for the 2019 Presidential
            elections. He was born to Lyiwola and Adeline Durotoye, both
            profesors at the University of Ife. After his parents moved to
            Obafemi Awolowo University, Ile- Ife, Fela attended the Staff
            Children’s School.
          </p>
        </li>
        <a href="" id="more">See More</a>
      </ul>
      <br />
      <br />
      <br />
      <p><b>Share this on:</b></p>
      <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
          
          <a class="a2a_button_facebook"></a>
          <a class="a2a_button_twitter"></a>
          <a class="a2a_button_linkedin"></a>
          <a class="a2a_button_whatsapp"></a>
        </div>
        <script async src="https://static.addtoany.com/menu/page.js"></script>
    </div>
@endsection
